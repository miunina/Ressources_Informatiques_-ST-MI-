from mininet.topo import Topo
#by debbah mehdi , AITHAMOUDA Adada Kenza
#AKLI Yassamine



#sudo mn --custom ~/mininet/custom/arbre.py --topo Arbre_gras --mac --link tc --controller=remote,ip=127.0.0.1 --switch=ovsk,protocols=OpenFlow13 

#PYTHONPATH=. ./bin/ryu-manager --verbose ryu/app/simple_switch_stp_13.py





class Arbre_gras( Topo ):

  #classe de creation d'un arbre a 3 niveau avec K switch coeurs

    CoreSwitchList = []# la liste des switch coeur 

    AggSwitchList = []# la liste des switch agregation

    EdgeSwitchList = []# la liste des switch edge

    HostList = []# la liste des  hotes 

 

    def __init__( self):

        

        n=4

        self.pod = n

        self.nbrCore = (n//2)**2 # nombre de switch de couche coeurs

        self.nbrAgg = n*n//2 #nombre de  switch de couche aggregation

        self.nbrEdge = n*n//2 #nombre de  switch de couche edge 

        self.density = n//2

        self.iHost = self.nbrEdge * self.density

        self.bw_co = 1000#bande passante pour le lien entre la couche coeur et agregation

        self.bw_ag = 500#bande passante pour le lien entre la couche  agregation et Edge 

        self.bw_h = 250#bande passante pour le lien entre la couche Edge et le host 

     

        # Initialiser la toplogie

        Topo.__init__(self)

        self.createTopo()

        self.Ajout_lien( )

   

    

    def createTopo(self):

        self.creation_switch()

        self.createHost(self.iHost)



    """

    Creation des switch et hotes

    """



    def _addSwitch(self, number, level, switch_list):

        # creation  de switchess 

        for x in range(1, number+1):

            idx = str(level) + "00"

            if x >= int(10):

                idx = str(level) + "0"

            switch_list.append(self.addSwitch('s' + idx + str(x)))



    def creation_switch(self):

        #creation de la couche coeurs 

        self._addSwitch(self.nbrCore, 1, self.CoreSwitchList)    

        # cration de couche agregation

        self._addSwitch(self.nbrAgg, 2, self.AggSwitchList)



       # creatiosn de couche edge 

        self._addSwitch(self.nbrEdge, 3, self.EdgeSwitchList)



    def createHost(self, NUMBER):

      # function de creation hote



        for x in range(1, NUMBER+1):

            #ajout d'un index pour savoir 

            # [h00] niveau

            # [h000] numero du host

            idx = "h00"

            if x >= int(10):

                idx = "h0"

            elif x >= int(100):

                idx = "h"

            self.HostList.append(self.addHost(idx + str(x)))



    """

    Ajout des liens 

    """

    def Ajout_lien(self):

       

        fin = self.pod//2 # le nombre de switch dans un pod 

        for x in range(0, self.nbrAgg, fin):

            for i in range(0, fin):

                for j in range(0, fin):

                    linkopts = dict(bw=self.bw_co) 

                    self.addLink(self.CoreSwitchList[i*fin+j],self.AggSwitchList[x+i],**linkopts)



        for x in range(0, self.nbrAgg, fin):

            for i in range(0, fin):

                for j in range(0, fin):

                   linkopts = dict(bw=self.bw_ag)

                   self.addLink( self.AggSwitchList[x+i], self.EdgeSwitchList[x+j],**linkopts)



       

        for x in range(0, self.nbrEdge):

            for i in range(0, self.density):

                linkopts = dict(bw=self.bw_h)

                self.addLink(self.EdgeSwitchList[x],self.HostList[self.density * x + i],**linkopts)



  

topos = { 'Arbre_gras' : ( lambda  : Arbre_gras()) }