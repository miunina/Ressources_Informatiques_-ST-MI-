
public class AppelEmis extends Appel {

}
