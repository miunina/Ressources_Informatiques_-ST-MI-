

public class AdresseException extends Exception {
public AdresseException (String s)
{
	System.out.println(s);
}
}
