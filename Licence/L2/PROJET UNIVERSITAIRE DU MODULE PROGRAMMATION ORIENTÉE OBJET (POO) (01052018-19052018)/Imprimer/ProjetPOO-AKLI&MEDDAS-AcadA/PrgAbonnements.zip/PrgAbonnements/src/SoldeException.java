
public class SoldeException extends Exception {
public SoldeException(String s)
{
	System.err.println(s);
}
}
