
public class AppelRecu extends Appel {

}
