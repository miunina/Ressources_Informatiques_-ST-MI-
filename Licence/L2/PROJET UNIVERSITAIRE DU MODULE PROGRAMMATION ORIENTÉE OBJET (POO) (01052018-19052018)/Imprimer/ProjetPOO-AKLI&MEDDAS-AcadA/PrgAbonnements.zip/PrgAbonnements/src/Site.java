

public enum Site {
	HOTMAIL,GMAIL,YAHOO,USTHB,OUTLOOK;
//public abstract void printString();
}