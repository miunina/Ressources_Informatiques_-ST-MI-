

public class DateException extends Exception {
public DateException(String s){System.err.println(s);}
}
