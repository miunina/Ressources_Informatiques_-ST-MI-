
public class SoldeInssuffisantException extends Exception {
public SoldeInssuffisantException(String s){System.err.println(s);}
}
