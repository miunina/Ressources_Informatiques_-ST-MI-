

public class HeureException extends Exception {
public HeureException(String s)
{
	System.err.println(s);
}
}

