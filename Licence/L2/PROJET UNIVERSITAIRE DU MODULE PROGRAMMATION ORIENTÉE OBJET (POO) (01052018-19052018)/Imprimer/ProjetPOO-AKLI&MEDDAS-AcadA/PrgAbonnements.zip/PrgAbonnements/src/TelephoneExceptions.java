

public class TelephoneExceptions extends Exception {
public TelephoneExceptions(String s)
{
	System.err.println(s);
}
}
