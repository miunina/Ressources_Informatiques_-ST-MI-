

public class NegativeException extends Exception {
public  NegativeException (String s)
{
	System.out.println(s);
}
}
